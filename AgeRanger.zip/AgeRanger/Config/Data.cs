﻿
namespace AgeRanger.Config
{
    public class Data
    {
        public DefaultConnection DefaultConnection { get; set; }
    }
}
