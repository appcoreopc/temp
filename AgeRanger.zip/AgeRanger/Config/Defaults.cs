﻿namespace AgeRanger.Config
{
    public class Defaults
    {
        public int PageSize { get; set; } = 10;
    }
}
